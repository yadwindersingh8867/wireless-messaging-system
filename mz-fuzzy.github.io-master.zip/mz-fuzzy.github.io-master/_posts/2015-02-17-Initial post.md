---
layout: post
title: Initial post
---
Welcome to by blog. Here, I want to document mostly for myself progress and findings of my (more or less serious) work. It will be mostly regarding:
* microcontrollers
* Internet of things
* SW development
* continuous integration
* linux

... and maybe other topics.

Enjoy reading!
